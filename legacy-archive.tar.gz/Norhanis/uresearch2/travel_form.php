<?php
include 'db_connect.php';

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$student_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $module_type = "travel";
    $status = "pending";

    $stmt = $conn->prepare("INSERT INTO applications (student_id, module_type, status, submitted_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $student_id, $module_type, $status);
    $stmt->execute();

    $application_id = $conn->insert_id;

    $type_of_request = $_POST['type_of_request'];
    $other_request_specify = $_POST['other_request_specify'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $duration = $_POST['duration'];
    $reason = $_POST['reason'];
    $destination = $_POST['destination'];
    $is_international = isset($_POST['is_international']) ? 1 : 0;
    $contact_name = $_POST['contact_name'];
    $contact_no = $_POST['contact_no'];

    $stmt2 = $conn->prepare("INSERT INTO travel_details (application_id, type_of_request, other_request_specify, travel_start_date, travel_end_date, duration_days, reason_for_travel, destination_address, is_international, contact_person_name, contact_person_no) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt2->bind_param("issssississ", $application_id, $type_of_request, $other_request_specify, $start_date, $end_date, $duration, $reason, $destination, $is_international, $contact_name, $contact_no);
    $stmt2->execute();

    $message = "Application submitted successfully. Application ID: " . $application_id;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Travel Application</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="top-header">
        <img src="images/UResearch_logo.png" alt="UResearch 2.0" class="uresearch-logo">
        <img src="images/UTP_logo.png" alt="UTP Logo" class="utp-logo">
    </div>

    <div class="dashboard-wrapper">
        <?php include 'sidebar.php'; ?>

        <div class="main-content">
            <div class="card-container-inline">
                <div class="card card-wide">
                    <h2>Travel Application</h2>
                    <div class="card-divider"></div>

                    <?php if ($message): ?>
                        <p class="message-success"><?php echo $message; ?></p>
                    <?php endif; ?>

                    <form method="POST">
                        <label>Type of Request</label>
                        <select name="type_of_request" required>
                            <option value="research_attachment">Research Attachment</option>
                            <option value="training_seminar_talk">Training/Seminar/Talk</option>
                            <option value="field_visit">Field Visit</option>
                            <option value="meeting">Meeting</option>
                            <option value="data_collection">Data Collection</option>
                            <option value="joint_supervision">Joint Supervision</option>
                            <option value="others">Others</option>
                        </select>

                        <label>If "Others", please specify</label>
                        <input type="text" name="other_request_specify">

                        <label>Start Date</label>
                        <input type="date" name="start_date" required>

                        <label>End Date</label>
                        <input type="date" name="end_date" required>

                        <label>Duration (days)</label>
                        <input type="number" name="duration" required>

                        <label>Reason for Travel</label>
                        <input type="text" name="reason" required>

                        <label>Destination</label>
                        <input type="text" name="destination" required>

                        <div class="checkbox-row">
                            <input type="checkbox" name="is_international" id="is_international">
                            <label for="is_international">International Travel</label>
                        </div>

                        <label>Contact Person Name</label>
                        <input type="text" name="contact_name">

                        <label>Contact Person No</label>
                        <input type="text" name="contact_no">

                        <button type="submit">Submit Application</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>