<?php
include 'db_connect.php';
include 'send_email.php';

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$approver_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $application_id = $_POST['application_id'];
    $decision = $_POST['decision'];
    $stage = "Lecturer/Supervisor";
    $remarks = $_POST['remarks'];

    $stmt = $conn->prepare("INSERT INTO approval_history (application_id, approver_id, stage, decision, remarks) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $application_id, $approver_id, $stage, $decision, $remarks);
    $stmt->execute();

    if ($decision == "endorsed") {
        $new_status = "endorsed";
        $new_stage = "Chair of Department";
    } else {
        $new_status = "rejected";
        $new_stage = null;
    }

    $stmt2 = $conn->prepare("UPDATE applications SET status = ?, current_stage = ? WHERE application_id = ?");
    $stmt2->bind_param("ssi", $new_status, $new_stage, $application_id);
    $stmt2->execute();

    $student_lookup = $conn->prepare("
        SELECT u.email, u.name FROM applications a
        JOIN users u ON a.student_id = u.user_id
        WHERE a.application_id = ?
    ");
    $student_lookup->bind_param("i", $application_id);
    $student_lookup->execute();
    $student = $student_lookup->get_result()->fetch_assoc();

    $email_subject = "Travel Application #" . $application_id . " Update";
    $email_body = "Hi " . $student['name'] . ",\n\nYour Travel application has been " . $new_status .
                  " at the Lecturer/Supervisor stage." .
                  ($new_stage ? " It now moves to: " . $new_stage . "." : "") .
                  "\n\nLog in to UResearch 2.0 to view details.";

    $email_result = send_notification_email($student['email'], $student['name'], $email_subject, $email_body);

    $message = "Application #" . $application_id . " marked as " . $new_status . ". Email status: " . $email_result;
}

$result = $conn->query("
    SELECT a.application_id, u.name AS student_name, t.reason_for_travel, t.destination_address,
           t.travel_start_date, t.travel_end_date, t.is_international
    FROM applications a
    JOIN users u ON a.student_id = u.user_id
    JOIN travel_details t ON a.application_id = t.application_id
    WHERE a.module_type = 'travel' AND a.status = 'pending'
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Travel Endorsement</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="top-header">
        <img src="images/UResearch_logo.png" alt="UResearch 2.0" class="uresearch-logo">
        <img src="images/UTP_logo.png" alt="UTP Logo" class="utp-logo">
    </div>

    <div class="dashboard-wrapper">
        <?php include 'sidebar.php'; ?>

        <div class="main-content">
            <h2>Travel Applications Pending Your Endorsement</h2>

            <?php if ($message): ?>
                <p class="message-success"><?php echo $message; ?></p>
            <?php endif; ?>

            <?php if ($result->num_rows == 0): ?>
                <p>No pending applications right now.</p>
            <?php endif; ?>

            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="app-item">
                    <p><b>Application #<?php echo $row['application_id']; ?></b></p>
                    <p>Student: <?php echo $row['student_name']; ?></p>
                    <p>Reason: <?php echo $row['reason_for_travel']; ?></p>
                    <p>Destination: <?php echo $row['destination_address']; ?></p>
                    <p>Dates: <?php echo $row['travel_start_date']; ?> to <?php echo $row['travel_end_date']; ?></p>
                    <p>International: <?php echo $row['is_international'] ? "Yes" : "No"; ?></p>

                    <form method="POST">
                        <input type="hidden" name="application_id" value="<?php echo $row['application_id']; ?>">
                        <label>Remarks</label>
                        <input type="text" name="remarks">
                        <br>
                        <button type="submit" name="decision" value="endorsed">Approve</button>
                        <button type="submit" name="decision" value="rejected">Reject</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>