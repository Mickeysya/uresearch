<?php
include 'db_connect.php';

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['role'];

// Work out which stage this role is responsible for, per module
$chart_labels = [];
$chart_data = [];

if ($role == 'supervisor') {
    $stage_filter = "status = 'pending'";
    $modules = ['travel', 'publication', 'claims_student'];
    $module_display = ['Travel', 'Publication', 'Claims'];
} elseif ($role == 'chair') {
    $stage_filter = "status = 'endorsed' AND current_stage = 'Chair of Department'";
    $modules = ['travel', 'publication', 'claims_student'];
    $module_display = ['Travel', 'Publication', 'Claims'];
} elseif ($role == 'non_exec_cgs') {
    $stage_filter = "status = 'endorsed' AND current_stage = 'Non-Executive CGS'";
    $modules = ['travel', 'publication', 'claims_student'];
    $module_display = ['Travel', 'Publication', 'Claims'];
} elseif ($role == 'dean_pgr') {
    $stage_filter = "status = 'reviewed' AND current_stage = 'Dean of PGR'";
    $modules = ['travel'];
    $module_display = ['Travel'];
} elseif ($role == 'senior_director_cgs') {
    $stage_filter = "status = 'reviewed' AND current_stage = 'Senior Director CGS'";
    $modules = ['publication'];
    $module_display = ['Publication'];
} elseif ($role == 'manager_cgs') {
    $stage_filter = "status = 'reviewed' AND current_stage = 'Manager CGS'";
    $modules = ['claims_student'];
    $module_display = ['Claims'];
} else {
    $modules = [];
    $module_display = [];
}

foreach ($modules as $i => $m) {
    $q = $conn->prepare("SELECT COUNT(*) AS cnt FROM applications WHERE module_type = ? AND $stage_filter");
    $q->bind_param("s", $m);
    $q->execute();
    $cnt = $q->get_result()->fetch_assoc()['cnt'];
    $chart_labels[] = $module_display[$i];
    $chart_data[] = (int)$cnt;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="top-header">
        <img src="images/UResearch_logo.png" alt="UResearch 2.0" class="uresearch-logo">
        <img src="images/UTP_logo.png" alt="UTP Logo" class="utp-logo">
    </div>

    <div class="dashboard-wrapper">
        <?php include 'sidebar.php'; ?>

        <div class="main-content">
            <div class="welcome-banner">
                <h2>Welcome, <?php echo $_SESSION['name']; ?></h2>
                <p><?php echo ucfirst(str_replace('_', ' ', $role)); ?></p>
            </div>

            <?php if ($role == 'student'): ?>
                <p style="color: var(--text-grey);">Select an item from the sidebar to get started.</p>

            <?php else: ?>
                <div class="chart-card">
                    <h3>Applications Pending Your Action</h3>
                    <canvas id="dashboardChart"></canvas>
                </div>

                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script>
                    const ctx = document.getElementById('dashboardChart');
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: <?php echo json_encode($chart_labels); ?>,
                            datasets: [{
                                label: 'Pending',
                                data: <?php echo json_encode($chart_data); ?>,
                                backgroundColor: '#284B80',
                                borderRadius: 6
                            }]
                        },
                        options: {
                            scales: {
                                y: { beginAtZero: true, ticks: { stepSize: 1 } }
                            },
                            plugins: {
                                legend: { display: false }
                            }
                        }
                    });
                </script>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>