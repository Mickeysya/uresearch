<?php
include 'db_connect.php';

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$student_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $module_type = "publication";
    $status = "pending";

    $stmt = $conn->prepare("INSERT INTO applications (student_id, module_type, status, submitted_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $student_id, $module_type, $status);
    $stmt->execute();

    $application_id = $conn->insert_id;

    $type_of_request = $_POST['type_of_request'];
    $title_of_paper = $_POST['title_of_paper'];
    $conference_or_journal = $_POST['conference_or_journal'];
    $organizer_publisher = $_POST['organizer_publisher'];
    $currency_type = $_POST['currency_type'];
    $cost = $_POST['cost'];
    $wants_lou = isset($_POST['wants_lou']) ? 1 : 0;
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    $stmt2 = $conn->prepare("INSERT INTO publication_details (application_id, type_of_request, title_of_paper, conference_or_journal, organizer_publisher, currency_type, cost_to_be_utilized, wants_letter_of_undertaking, conference_start_date, conference_end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt2->bind_param("isssssdiss", $application_id, $type_of_request, $title_of_paper, $conference_or_journal, $organizer_publisher, $currency_type, $cost, $wants_lou, $start_date, $end_date);
    $stmt2->execute();

    $publication_id = $conn->insert_id;

    $author_name = $_POST['author_name'];
    $organisation = $_POST['organisation'];
    $role_contribution = $_POST['role_contribution'];

    $stmt3 = $conn->prepare("INSERT INTO publication_authors (publication_id, author_name, organisation, role_contribution) VALUES (?, ?, ?, ?)");
    $stmt3->bind_param("isss", $publication_id, $author_name, $organisation, $role_contribution);
    $stmt3->execute();

    $message = "Application submitted successfully. Application ID: " . $application_id;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Publication Application</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="top-header">
        <img src="images/UResearch_logo.png" alt="UResearch 2.0" class="uresearch-logo">
        <img src="images/UTP_logo.png" alt="UTP Logo" class="utp-logo">
    </div>

    <div class="dashboard-wrapper">
        <?php include 'sidebar.php'; ?>

        <div class="main-content">
            <div class="card-container-inline">
                <div class="card card-wide">
                    <h2>Publication Application</h2>
                    <div class="card-divider"></div>

                    <?php if ($message): ?>
                        <p class="message-success"><?php echo $message; ?></p>
                    <?php endif; ?>

                    <form method="POST">
                        <label>Type of Request</label>
                        <select name="type_of_request">
                            <option value="publication_conference">Conference</option>
                            <option value="publication_journal">Journal</option>
                        </select>

                        <label>Title of Paper</label>
                        <input type="text" name="title_of_paper" required>

                        <label>Conference/Journal Name</label>
                        <input type="text" name="conference_or_journal" required>

                        <label>Organizer/Publisher</label>
                        <input type="text" name="organizer_publisher">

                        <label>Currency</label>
                        <input type="text" name="currency_type" placeholder="e.g. MYR">

                        <label>Cost</label>
                        <input type="number" step="0.01" name="cost">

                        <div class="checkbox-row">
                            <input type="checkbox" name="wants_lou" id="wants_lou">
                            <label for="wants_lou">Requesting Letter of Undertaking</label>
                        </div>

                        <label>Conference/Submission Start Date</label>
                        <input type="date" name="start_date">

                        <label>Conference/Submission End Date</label>
                        <input type="date" name="end_date">

                        <h3 style="margin-top: 24px; margin-bottom: 4px;">Author</h3>
                        <label>Author Name</label>
                        <input type="text" name="author_name" required>

                        <label>Organisation</label>
                        <input type="text" name="organisation">

                        <label>Role/Contribution</label>
                        <input type="text" name="role_contribution">

                        <button type="submit">Submit Application</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>