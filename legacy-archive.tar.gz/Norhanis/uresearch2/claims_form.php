<?php
include 'db_connect.php';

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$student_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $module_type = "claims_student";
    $status = "pending";

    $stmt = $conn->prepare("INSERT INTO applications (student_id, module_type, status, submitted_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $student_id, $module_type, $status);
    $stmt->execute();

    $application_id = $conn->insert_id;

    $purpose = $_POST['purpose'];
    $bank_account_no = $_POST['bank_account_no'];
    $total_claim_amount = $_POST['total_claim_amount'];
    $less_cash_advance = $_POST['less_cash_advance'];
    $claim_balance = $total_claim_amount - $less_cash_advance;

    $stmt2 = $conn->prepare("INSERT INTO claims_details (application_id, purpose_of_claim, bank_account_no, total_claim_amount, less_cash_advance, claim_balance) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt2->bind_param("issddd", $application_id, $purpose, $bank_account_no, $total_claim_amount, $less_cash_advance, $claim_balance);
    $stmt2->execute();

    $claim_id = $conn->insert_id;

    $item_dates = $_POST['item_date'];
    $travel_froms = $_POST['travel_from'];
    $travel_tos = $_POST['travel_to'];
    $flight_amounts = $_POST['flight_amount'];
    $meal_amounts = $_POST['meal_amount'];
    $lodging_amounts = $_POST['lodging_amount'];
    $misc_amounts = $_POST['misc_amount'];

    for ($i = 0; $i < count($item_dates); $i++) {
        if ($item_dates[$i] == "") continue;

        $stmt3 = $conn->prepare("INSERT INTO claims_items (claim_id, item_date, travel_from, travel_to, flight_train_amount, meal_allowance, lodging_amount, misc_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt3->bind_param("isssdddd", $claim_id, $item_dates[$i], $travel_froms[$i], $travel_tos[$i], $flight_amounts[$i], $meal_amounts[$i], $lodging_amounts[$i], $misc_amounts[$i]);
        $stmt3->execute();
    }

    $message = "Application submitted successfully. Application ID: " . $application_id;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Claims Application</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="top-header">
        <img src="images/UResearch_logo.png" alt="UResearch 2.0" class="uresearch-logo">
        <img src="images/UTP_logo.png" alt="UTP Logo" class="utp-logo">
    </div>

    <div class="dashboard-wrapper">
        <?php include 'sidebar.php'; ?>

        <div class="main-content">
            <div class="card-container-inline">
                <div class="card card-wide">
                    <h2>Student Claims Application</h2>
                    <div class="card-divider"></div>

                    <?php if ($message): ?>
                        <p class="message-success"><?php echo $message; ?></p>
                    <?php endif; ?>

                    <form method="POST">
                        <label>Purpose of Claim</label>
                        <input type="text" name="purpose" required>

                        <label>Bank Account No</label>
                        <input type="text" name="bank_account_no" required>

                        <label>Total Claim Amount (RM)</label>
                        <input type="number" step="0.01" name="total_claim_amount" required>

                        <label>Less Cash Advance (RM)</label>
                        <input type="number" step="0.01" name="less_cash_advance" value="0">

                        <h3 style="margin-top: 24px; margin-bottom: 4px;">Expense Item 1</h3>
                        <label>Date</label>
                        <input type="date" name="item_date[]">
                        <label>Travel From</label>
                        <input type="text" name="travel_from[]">
                        <label>Travel To</label>
                        <input type="text" name="travel_to[]">
                        <label>Flight/Train Amount (RM)</label>
                        <input type="number" step="0.01" name="flight_amount[]" value="0">
                        <label>Meal Allowance (RM)</label>
                        <input type="number" step="0.01" name="meal_amount[]" value="0">
                        <label>Lodging (RM)</label>
                        <input type="number" step="0.01" name="lodging_amount[]" value="0">
                        <label>Miscellaneous (RM)</label>
                        <input type="number" step="0.01" name="misc_amount[]" value="0">

                        <h3 style="margin-top: 24px; margin-bottom: 4px;">Expense Item 2</h3>
                        <label>Date</label>
                        <input type="date" name="item_date[]">
                        <label>Travel From</label>
                        <input type="text" name="travel_from[]">
                        <label>Travel To</label>
                        <input type="text" name="travel_to[]">
                        <label>Flight/Train Amount (RM)</label>
                        <input type="number" step="0.01" name="flight_amount[]" value="0">
                        <label>Meal Allowance (RM)</label>
                        <input type="number" step="0.01" name="meal_amount[]" value="0">
                        <label>Lodging (RM)</label>
                        <input type="number" step="0.01" name="lodging_amount[]" value="0">
                        <label>Miscellaneous (RM)</label>
                        <input type="number" step="0.01" name="misc_amount[]" value="0">

                        <button type="submit">Submit Application</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>