<?php
include 'db_connect.php';
include 'send_email.php';

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$approver_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $application_id = $_POST['application_id'];
    $decision = $_POST['decision'];
    $remarks = $_POST['remarks'];
    $stage = "Non-Executive CGS";

    $stmt = $conn->prepare("INSERT INTO approval_history (application_id, approver_id, stage, decision, remarks) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $application_id, $approver_id, $stage, $decision, $remarks);
    $stmt->execute();

    if ($decision == "rejected") {
        $new_status = "rejected";
        $new_stage = null;
    } else {
        $new_status = "reviewed";
        $new_stage = "Senior Director CGS";
    }

    $stmt2 = $conn->prepare("UPDATE applications SET status = ?, current_stage = ? WHERE application_id = ?");
    $stmt2->bind_param("ssi", $new_status, $new_stage, $application_id);
    $stmt2->execute();

    $student_lookup = $conn->prepare("
        SELECT u.email, u.name FROM applications a
        JOIN users u ON a.student_id = u.user_id
        WHERE a.application_id = ?
    ");
    $student_lookup->bind_param("i", $application_id);
    $student_lookup->execute();
    $student = $student_lookup->get_result()->fetch_assoc();

    $email_subject = "Publication Application #" . $application_id . " Update";
    $email_body = "Hi " . $student['name'] . ",\n\nYour Publication application has been " . $new_status .
                  " at the Non-Executive CGS stage." .
                  ($new_stage ? " It now moves to: " . $new_stage . "." : " This is the final decision for your application.") .
                  "\n\nLog in to UResearch 2.0 to view details.";

    $email_result = send_notification_email($student['email'], $student['name'], $email_subject, $email_body);

    $message = "Application #" . $application_id . " updated to " . $new_status . ($new_stage ? " (next: " . $new_stage . ")" : " (final)") . ". Email status: " . $email_result;
}

$result = $conn->query("
    SELECT a.application_id, u.name AS student_name, p.title_of_paper, p.conference_or_journal
    FROM applications a
    JOIN users u ON a.student_id = u.user_id
    JOIN publication_details p ON a.application_id = p.application_id
    WHERE a.module_type = 'publication' AND a.status = 'endorsed' AND a.current_stage = 'Non-Executive CGS'
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Non-Executive CGS Review</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="top-header">
        <img src="images/UResearch_logo.png" alt="UResearch 2.0" class="uresearch-logo">
        <img src="images/UTP_logo.png" alt="UTP Logo" class="utp-logo">
    </div>

    <div class="dashboard-wrapper">
        <?php include 'sidebar.php'; ?>

        <div class="main-content">
            <h2>Publication Applications Pending CGS Review</h2>

            <?php if ($message): ?>
                <p class="message-success"><?php echo $message; ?></p>
            <?php endif; ?>

            <?php if ($result->num_rows == 0): ?>
                <p>No applications waiting right now.</p>
            <?php endif; ?>

            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="app-item">
                    <p><b>Application #<?php echo $row['application_id']; ?></b></p>
                    <p>Student: <?php echo $row['student_name']; ?></p>
                    <p>Paper: <?php echo $row['title_of_paper']; ?></p>

                    <form method="POST">
                        <input type="hidden" name="application_id" value="<?php echo $row['application_id']; ?>">
                        <label>Remarks</label>
                        <input type="text" name="remarks">
                        <br>
                        <button type="submit" name="decision" value="approved">Approve</button>
                        <button type="submit" name="decision" value="rejected">Reject</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>