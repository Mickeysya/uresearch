<?php
include 'db_connect.php';

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'supervisor') {
    header("Location: login.php");
    exit;
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Step 1: create the shared application record first
    $student_id = $_SESSION['user_id']; // supervisor is the applicant here
    $module_type = "examiner_nomination";
    $status = "pending";
    $current_stage = "Academic Executive";

    $stmt = $conn->prepare("INSERT INTO applications (student_id, module_type, status, current_stage, submitted_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("isss", $student_id, $module_type, $status, $current_stage);
    $stmt->execute();

    $application_id = $conn->insert_id; // grabs the ID just created above

    // Step 2: save the examiner nomination details, linked by application_id
    $examiner_name = $_POST['examiner_name'];
    $examiner_email = $_POST['examiner_email'];
    $examiner_department = $_POST['examiner_department'];
    $examiner_type = $_POST['examiner_type'];
    $last_examination_date = $_POST['last_examination_date'] !== '' ? $_POST['last_examination_date'] : null;

    $stmt2 = $conn->prepare("INSERT INTO examiner_nominations (application_id, examiner_name, examiner_email, examiner_department, examiner_type, last_examination_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt2->bind_param("isssss", $application_id, $examiner_name, $examiner_email, $examiner_department, $examiner_type, $last_examination_date);
    $stmt2->execute();

    $message = "Nomination submitted successfully. Application ID: " . $application_id;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Examiner Nomination</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="top-header">
        <img src="../images/UResearch_logo.png" alt="UResearch 2.0" class="uresearch-logo">
        <img src="../images/UTP_logo.png" alt="UTP Logo" class="utp-logo">
    </div>

    <div class="dashboard-wrapper">
        <?php $role = $_SESSION['role']; include 'sidebar.php'; ?>

        <div class="main-content">
            <h2>Examiner Nomination Form</h2>

            <?php if ($message): ?>
                <p class="message-success"><?php echo htmlspecialchars($message); ?></p>
            <?php endif; ?>

            <form method="POST">
                Examiner Name: <input type="text" name="examiner_name" required><br><br>
                Examiner Email: <input type="email" name="examiner_email" required><br><br>
                Examiner Department: <input type="text" name="examiner_department" required><br><br>
                Examiner Type:
                <select name="examiner_type" required>
                    <option value="">-- Select --</option>
                    <option value="internal">Internal</option>
                    <option value="external">External</option>
                </select><br><br>
                Last Examination Date (if any): <input type="date" name="last_examination_date"><br><br>
                <button type="submit">Submit Nomination</button>
            </form>
        </div>
    </div>
</body>
</html>
