<?php
include 'db_connect.php';

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'academic_exec') {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['role'];
$approver_id = $_SESSION['user_id'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $application_id = $_POST['application_id'];
    $decision = $_POST['decision']; // 'approved' or 'rejected'
    $remarks = $_POST['remarks'] !== '' ? $_POST['remarks'] : null;
    $stage = "Academic Executive";

    $h = $conn->prepare("INSERT INTO approval_history (application_id, approver_id, stage, decision, remarks) VALUES (?, ?, ?, ?, ?)");
    $h->bind_param("iisss", $application_id, $approver_id, $stage, $decision, $remarks);
    $h->execute();

    $new_stage = $decision === 'approved' ? 'Approved' : $stage;
    $u = $conn->prepare("UPDATE applications SET status = ?, current_stage = ? WHERE application_id = ?");
    $u->bind_param("ssi", $decision, $new_stage, $application_id);
    $u->execute();

    $message = "Nomination #" . $application_id . " has been " . $decision . ".";
}

$pending = $conn->prepare("
    SELECT a.application_id, a.submitted_at, u.name AS supervisor_name,
           n.examiner_name, n.examiner_email, n.examiner_department, n.examiner_type, n.last_examination_date
    FROM applications a
    JOIN examiner_nominations n ON n.application_id = a.application_id
    JOIN users u ON u.user_id = a.student_id
    WHERE a.module_type = 'examiner_nomination' AND a.status = 'pending'
    ORDER BY a.submitted_at ASC
");
$pending->execute();
$pending_result = $pending->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Examiner Nomination Approval</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="top-header">
        <img src="images/UResearch_logo.png" alt="UResearch 2.0" class="uresearch-logo">
        <img src="images/UTP_logo.png" alt="UTP Logo" class="utp-logo">
    </div>

    <div class="dashboard-wrapper">
        <?php include 'sidebar.php'; ?>

        <div class="main-content">
            <h2>Examiner Nomination Approval</h2>

            <?php if ($message): ?>
                <p class="message-success"><?php echo htmlspecialchars($message); ?></p>
            <?php endif; ?>

            <?php if ($pending_result->num_rows == 0): ?>
                <p>No examiner nominations pending your approval.</p>
            <?php endif; ?>

            <?php while ($row = $pending_result->fetch_assoc()): ?>
                <div class="app-item">
                    <p><b>Nomination #<?php echo $row['application_id']; ?></b> — submitted by <?php echo htmlspecialchars($row['supervisor_name']); ?></p>
                    <p>
                        Examiner: <?php echo htmlspecialchars($row['examiner_name']); ?>
                        (<?php echo ucfirst(htmlspecialchars($row['examiner_type'])); ?>)<br>
                        Email: <?php echo htmlspecialchars($row['examiner_email']); ?><br>
                        Department: <?php echo htmlspecialchars($row['examiner_department']); ?><br>
                        <?php if ($row['last_examination_date']): ?>
                            Last Examination Date: <?php echo htmlspecialchars($row['last_examination_date']); ?><br>
                        <?php endif; ?>
                    </p>

                    <form method="POST">
                        <input type="hidden" name="application_id" value="<?php echo $row['application_id']; ?>">
                        Remarks (optional): <input type="text" name="remarks"><br><br>
                        <button type="submit" name="decision" value="approved">Approve</button>
                        <button type="submit" name="decision" value="rejected">Reject</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>
