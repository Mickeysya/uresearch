<?php
session_start();
include '../../shared/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$role = $_SESSION['role'];
$student_id = $_SESSION['user_id'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_end_date = $_POST['current_end_date'];
    $requested_new_end_date = $_POST['requested_new_end_date'];
    $reason = $_POST['reason'];
    $document_path = "";

    // Handle file upload if provided
    if (isset($_FILES['supporting_document']) && $_FILES['supporting_document']['error'] == 0) {
        $upload_dir = "../../uploads/ga_extension/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $filename = time() . "_" . basename($_FILES['supporting_document']['name']);
        $target_path = $upload_dir . $filename;
        if (move_uploaded_file($_FILES['supporting_document']['tmp_name'], $target_path)) {
            $document_path = "uploads/ga_extension/" . $filename;
        }
    }

    // Step 1: insert into shared applications table first
    $stmt = $conn->prepare("INSERT INTO applications (student_id, module_type, status, submitted_at) VALUES (?, 'ga_extension', 'pending', NOW())");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $application_id = $conn->insert_id;

    // Step 2: insert module-specific details, linked by application_id
    $stmt2 = $conn->prepare("INSERT INTO ga_extension_details (application_id, current_end_date, requested_new_end_date, reason_for_extension, supporting_document_path) VALUES (?, ?, ?, ?, ?)");
    $stmt2->bind_param("issss", $application_id, $current_end_date, $requested_new_end_date, $reason, $document_path);
    $stmt2->execute();

    $message = "GA Extension application #" . $application_id . " submitted successfully.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>GA Extension Application</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="top-header">
        <img src="../../shared/images/UResearch_logo.png" alt="UResearch 2.0" class="uresearch-logo">
        <img src="../../shared/images/UTP_logo.png" alt="UTP Logo" class="utp-logo">
    </div>

    <div class="dashboard-wrapper">
        <?php include '../sidebar.php'; ?>

        <div class="main-content">
            <?php if ($message): ?>
                <p class="message-success"><?php echo $message; ?></p>
            <?php endif; ?>

            <div class="card-container-inline">
                <div class="card card-wide">
                    <h2>GA Extension Application</h2>
                    <div class="card-divider"></div>

                    <form method="POST" enctype="multipart/form-data">
                        <label>Current GA End Date</label>
                        <input type="date" name="current_end_date" required>

                        <label>Requested New End Date</label>
                        <input type="date" name="requested_new_end_date" required>

                        <label>Reason for Extension</label>
                        <input type="text" name="reason" required>

                        <label>Supporting Document</label>
                        <input type="file" name="supporting_document">

                        <button type="submit">Submit Application</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>